export const API_BASE_URL = "http://10.25.224.125:8000";

export default function Config() {
    return null;
}
